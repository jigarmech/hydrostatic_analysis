classdef app1_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure              matlab.ui.Figure
        FileNameLabel         matlab.ui.control.Label
        UpdateButton          matlab.ui.control.Button
        SummaryTextArea       matlab.ui.control.TextArea
        SummaryTextAreaLabel  matlab.ui.control.Label
        FileuploadButton      matlab.ui.control.Button
        UIAxes                matlab.ui.control.UIAxes
    end

    
    properties (Access = private)
        new_x % Description
        new_y
        new_z
        range_z
        stlFile
        smodel
    end
    
    methods (Access = public)
        
        function results = func(app)
            app.smodel = createpde('structural','static-solid');
            importGeometry(app.smodel,app.stlFile);
        end
        function createGeometryPlot(app)

            % Plot the geometry using pdegplot
            pdegplot(app.smodel, 'FaceLabels', 'on', 'FaceAlpha', 0.5);
            
            
        end
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: FileuploadButton
        function FileuploadButtonPushed(app, event)
            [filename, pathname] = uigetfile({'*.stl'},'File Selector');
            if ~isequal(filename,0)
                app.stlFile = fullfile(pathname,filename);
                [F,~] = stlread(app.stlFile);
                % Do something with F and V   
                x=F.Points(:,1);
                y=F.Points(:,2);
                z=F.Points(:,end);
                min_x=min(x);
                min_y=min(y);
                min_z=min(z);
                app.new_x = x-min_x;
                app.new_y = y-min_y;
                app.new_z = z-min_z;
                Max_point_z = max(app.new_z);
                Max_point_x = max(app.new_x);
                Max_point_y = max(app.new_y);
                app.FileNameLabel.Text = filename;
                app.SummaryTextArea.Value = sprintf(['File uploaded successfully!\nMax_point in z direction = %f \n' ...
                'Max_point in x direction = %f \nMax_point in y direction = %f \nPlease click on Update button'],...
                Max_point_z,Max_point_x,Max_point_y);
                app.SummaryTextArea.FontColor = 'b';
                app.FileuploadButton.BackgroundColor = [0.98,0.88,0.85];
                app.UpdateButton.BackgroundColor = [0.86,0.95,0.82];
                
                app.UpdateButton.Enable = "on";
                
                
            else
                app.SummaryTextArea.Value = 'File upload failed.';
                app.SummaryTextArea.FontColor = 'r';
                app.FileuploadButton.BackgroundColor = [0.86,0.95,0.82];
                app.UpdateButton.BackgroundColor = [0.98,0.88,0.85];
                app.FileNameLabel.Text = "File Name";
                
                app.UpdateButton.Enable = "off";
                
            return;
            end
        end

        % Button pushed function: UpdateButton
        function UpdateButtonPushed(app, event)
            %pdeplot3D(app.smodel,"ElementLabels","on","FaceAlpha",0.5);
            
            createGeometryPlot(app);
            
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 640 480];
            app.UIFigure.Name = 'MATLAB App';

            % Create UIAxes
            app.UIAxes = uiaxes(app.UIFigure);
            title(app.UIAxes, 'Title')
            xlabel(app.UIAxes, 'X')
            ylabel(app.UIAxes, 'Y')
            zlabel(app.UIAxes, 'Z')
            app.UIAxes.Position = [33 164 418 247];

            % Create FileuploadButton
            app.FileuploadButton = uibutton(app.UIFigure, 'push');
            app.FileuploadButton.ButtonPushedFcn = createCallbackFcn(app, @FileuploadButtonPushed, true);
            app.FileuploadButton.BackgroundColor = [0.8588 0.949 0.8196];
            app.FileuploadButton.Position = [33 410 100 23];
            app.FileuploadButton.Text = 'File upload';

            % Create SummaryTextAreaLabel
            app.SummaryTextAreaLabel = uilabel(app.UIFigure);
            app.SummaryTextAreaLabel.HorizontalAlignment = 'right';
            app.SummaryTextAreaLabel.Position = [33 143 57 22];
            app.SummaryTextAreaLabel.Text = 'Summary';

            % Create SummaryTextArea
            app.SummaryTextArea = uitextarea(app.UIFigure);
            app.SummaryTextArea.Position = [35 13 515 131];

            % Create UpdateButton
            app.UpdateButton = uibutton(app.UIFigure, 'push');
            app.UpdateButton.ButtonPushedFcn = createCallbackFcn(app, @UpdateButtonPushed, true);
            app.UpdateButton.BackgroundColor = [0.9804 0.8784 0.851];
            app.UpdateButton.FontWeight = 'bold';
            app.UpdateButton.Enable = 'off';
            app.UpdateButton.Position = [456 410 72 21];
            app.UpdateButton.Text = 'Update';

            % Create FileNameLabel
            app.FileNameLabel = uilabel(app.UIFigure);
            app.FileNameLabel.Position = [33 444 251 23];
            app.FileNameLabel.Text = 'File Name';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = app1_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end