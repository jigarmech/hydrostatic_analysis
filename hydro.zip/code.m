smodel = createpde('structural','static-solid');

% Import STL file
importGeometry(smodel,"rectangle_container.stl");
pdegplot(smodel,"FaceLabels","on","FaceAlpha",0.5);
% Generate Mesh
msh = generateMesh(smodel,"Hmax",3);
pdeplot3D(smodel)

% Define material properties
E = 2e9; % Young's modulus (Pa)
nu = 0.3; % Poisson's ratio
structuralProperties(smodel, 'YoungsModulus', E, 'PoissonsRatio', nu);

% Define Boundary condition
rho = 1000;
g=9.81;

% Define the height and slope
h0 = 10; % Initial height
m = 0.5; % Slope

% Define the hydrostatic pressure expression
%pressureExpression = sprintf('rho*g*(%f - %f*y)', h0, m);
p1=50000;
% Apply the boundary condition with the hydrostatic pressure
structuralBC(smodel, 'Face', 6,"Constraint","fixed");

structuralBoundaryLoad(smodel, 'Face', [8, 9, 10, 11], 'Pressure', p1);

%Post process
Rs = solve(smodel);
% Calculate element stresses
pdeplot3D(smodel,"ColorMapData",Rs.VonMisesStress,"Deformation",Rs.Displacement,"DeformationScaleFactor",1)
pdeplot3D(smodel,"ColorMapData",Rs.Displacement.Magnitude,"Deformation",Rs.Displacement,"DeformationScaleFactor",1)
